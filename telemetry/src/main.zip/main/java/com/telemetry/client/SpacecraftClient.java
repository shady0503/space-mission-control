package com.telemetry.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.UUID;

@FeignClient(name="spacecraft-service", url="${spacecraft.url}")
public interface SpacecraftClient {
    @GetMapping("/api/spacecraft/summary")
    List<SpacecraftSummary> findAllSummary();
    record SpacecraftSummary(UUID id, Long externalId, UUID entrepriseId) {}
}
