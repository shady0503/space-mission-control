package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List; /**
 * DTO for aggregated time series.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AggregatedTimeSeriesDTO {
    private String parameter;
    private String interval;
    private List<AggregatedPoint> data;

    public static class AggregatedPoint {
        private long timestamp;
        private double avg;
        private double min;
        private double max;
        private long count;

        public AggregatedPoint() {
        }

        public AggregatedPoint(long timestamp, double avg, double min, double max, long count) {
            this.timestamp = timestamp;
            this.avg = avg;
            this.min = min;
            this.max = max;
            this.count = count;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public double getAvg() {
            return avg;
        }

        public void setAvg(double avg) {
            this.avg = avg;
        }

        public double getMin() {
            return min;
        }

        public void setMin(double min) {
            this.min = min;
        }

        public double getMax() {
            return max;
        }

        public void setMax(double max) {
            this.max = max;
        }

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }
    }

    public AggregatedTimeSeriesDTO() {
    }

    public AggregatedTimeSeriesDTO(String parameter, String interval, List<AggregatedPoint> data) {
        this.parameter = parameter;
        this.interval = interval;
        this.data = data;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getInterval() {
        return interval;
    }

    public void setInterval(String interval) {
        this.interval = interval;
    }

    public List<AggregatedPoint> getData() {
        return data;
    }

    public void setData(List<AggregatedPoint> data) {
        this.data = data;
    }
}
