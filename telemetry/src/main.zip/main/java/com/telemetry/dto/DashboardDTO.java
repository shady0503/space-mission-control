package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map; /**
 * DTO for dashboard data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DashboardDTO {
    private Map<String, Object> latest;
    private Map<String, Object> statistics;
    private List<Map<String, Object>> recentTrajectory;
    private List<Map<String, Object>> velocityChart;
    private List<Map<String, Object>> altitudeChart;

    public DashboardDTO() {
    }

    public Map<String, Object> getLatest() {
        return latest;
    }

    public void setLatest(Map<String, Object> latest) {
        this.latest = latest;
    }

    public Map<String, Object> getStatistics() {
        return statistics;
    }

    public void setStatistics(Map<String, Object> statistics) {
        this.statistics = statistics;
    }

    public List<Map<String, Object>> getRecentTrajectory() {
        return recentTrajectory;
    }

    public void setRecentTrajectory(List<Map<String, Object>> recentTrajectory) {
        this.recentTrajectory = recentTrajectory;
    }

    public List<Map<String, Object>> getVelocityChart() {
        return velocityChart;
    }

    public void setVelocityChart(List<Map<String, Object>> velocityChart) {
        this.velocityChart = velocityChart;
    }

    public List<Map<String, Object>> getAltitudeChart() {
        return altitudeChart;
    }

    public void setAltitudeChart(List<Map<String, Object>> altitudeChart) {
        this.altitudeChart = altitudeChart;
    }
}
