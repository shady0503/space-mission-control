package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.sql.Timestamp;
import java.util.Map; /**
 * DTO for latest telemetry point.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LatestTelemetryPointDTO {
    private Map<String, Double> position;
    private Map<String, Double> velocity;
    private Map<String, Object> location;
    private Map<String, Object> attitude;
    private double acceleration;
    private double orbitRadius;
    private Timestamp timestamp;
    private String source;

    public LatestTelemetryPointDTO() {
    }

    public Map<String, Double> getPosition() {
        return position;
    }

    public void setPosition(Map<String, Double> position) {
        this.position = position;
    }

    public Map<String, Double> getVelocity() {
        return velocity;
    }

    public void setVelocity(Map<String, Double> velocity) {
        this.velocity = velocity;
    }

    public Map<String, Object> getLocation() {
        return location;
    }

    public void setLocation(Map<String, Object> location) {
        this.location = location;
    }

    public Map<String, Object> getAttitude() {
        return attitude;
    }

    public void setAttitude(Map<String, Object> attitude) {
        this.attitude = attitude;
    }

    public double getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    public double getOrbitRadius() {
        return orbitRadius;
    }

    public void setOrbitRadius(double orbitRadius) {
        this.orbitRadius = orbitRadius;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
