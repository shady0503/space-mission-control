package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Map; /**
 * DTO for spacecraft statistics.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SpacecraftStatisticsDTO {
    private Map<String, Object> timeRange;
    private int dataPoints;
    private Map<String, Object> velocity;
    private Map<String, Object> acceleration;
    private Map<String, Object> altitude;
    private Map<String, Object> last24Hours;

    public SpacecraftStatisticsDTO() {
    }

    public Map<String, Object> getTimeRange() {
        return timeRange;
    }

    public void setTimeRange(Map<String, Object> timeRange) {
        this.timeRange = timeRange;
    }

    public int getDataPoints() {
        return dataPoints;
    }

    public void setDataPoints(int dataPoints) {
        this.dataPoints = dataPoints;
    }

    public Map<String, Object> getVelocity() {
        return velocity;
    }

    public void setVelocity(Map<String, Object> velocity) {
        this.velocity = velocity;
    }

    public Map<String, Object> getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(Map<String, Object> acceleration) {
        this.acceleration = acceleration;
    }

    public Map<String, Object> getAltitude() {
        return altitude;
    }

    public void setAltitude(Map<String, Object> altitude) {
        this.altitude = altitude;
    }

    public Map<String, Object> getLast24Hours() {
        return last24Hours;
    }

    public void setLast24Hours(Map<String, Object> last24Hours) {
        this.last24Hours = last24Hours;
    }
}
