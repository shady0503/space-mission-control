package com.telemetry.dto;

import java.util.List;

public class TelemetryWithPredictionResponse {

    private TelemetryResponse telemetry;
    private List<PredictedPosition> predictions;

    public TelemetryWithPredictionResponse() {
    }

    public TelemetryWithPredictionResponse(TelemetryResponse telemetry, List<PredictedPosition> predictions) {
        this.telemetry = telemetry;
        this.predictions = predictions;
    }

    public TelemetryResponse getTelemetry() {
        return telemetry;
    }

    public void setTelemetry(TelemetryResponse telemetry) {
        this.telemetry = telemetry;
    }

    public List<PredictedPosition> getPredictions() {
        return predictions;
    }

    public void setPredictions(List<PredictedPosition> predictions) {
        this.predictions = predictions;
    }

    public static class PredictedPosition {
        private float x;
        private float y;
        private float z;
        private long timestamp;

        public PredictedPosition() {
        }

        public PredictedPosition(float x, float y, float z, long timestamp) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.timestamp = timestamp;
        }

        public float getX() {
            return x;
        }

        public void setX(float x) {
            this.x = x;
        }

        public float getY() {
            return y;
        }

        public void setY(float y) {
            this.y = y;
        }

        public float getZ() {
            return z;
        }

        public void setZ(float z) {
            this.z = z;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }
    }
}
