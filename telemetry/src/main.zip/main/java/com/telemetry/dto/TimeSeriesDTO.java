package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List; /**
 * DTO for time series data (charts).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimeSeriesDTO {
    private String parameter;
    private String unit;
    private List<TimeSeriesPoint> data;

    public static class TimeSeriesPoint {
        private long timestamp;
        private double value;

        public TimeSeriesPoint() {
        }

        public TimeSeriesPoint(long timestamp, double value) {
            this.timestamp = timestamp;
            this.value = value;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public double getValue() {
            return value;
        }

        public void setValue(double value) {
            this.value = value;
        }
    }

    public TimeSeriesDTO() {
    }

    public TimeSeriesDTO(String parameter, String unit, List<TimeSeriesPoint> data) {
        this.parameter = parameter;
        this.unit = unit;
        this.data = data;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public List<TimeSeriesPoint> getData() {
        return data;
    }

    public void setData(List<TimeSeriesPoint> data) {
        this.data = data;
    }
}
