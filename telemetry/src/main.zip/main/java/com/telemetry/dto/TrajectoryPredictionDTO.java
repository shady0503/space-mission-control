package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map; /**
 * DTO for trajectory with prediction.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrajectoryPredictionDTO {
    private List<Map<String, Object>> actual;
    private List<Map<String, Object>> shortTermPrediction;
    private List<Map<String, Object>> fullOrbitPrediction;

    public TrajectoryPredictionDTO() {
    }

    public List<Map<String, Object>> getActual() {
        return actual;
    }

    public void setActual(List<Map<String, Object>> actual) {
        this.actual = actual;
    }

    public List<Map<String, Object>> getShortTermPrediction() {
        return shortTermPrediction;
    }

    public void setShortTermPrediction(List<Map<String, Object>> shortTermPrediction) {
        this.shortTermPrediction = shortTermPrediction;
    }

    public List<Map<String, Object>> getFullOrbitPrediction() {
        return fullOrbitPrediction;
    }

    public void setFullOrbitPrediction(List<Map<String, Object>> fullOrbitPrediction) {
        this.fullOrbitPrediction = fullOrbitPrediction;
    }
}
