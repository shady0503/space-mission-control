package com.telemetry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
 * DTOs for visualization data responses.
 */

/**
 * DTO for trajectory data response.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrajectoryVisualizationDTO {
    private List<TrajectoryPoint> points;
    private Map<String, Object> metadata;

    public static class TrajectoryPoint {
        private long timestamp;
        private double[] position; // [x, y, z]
        private double[] geo;      // [lat, long, alt] - optional
        private double velocity;

        public TrajectoryPoint() {
        }

        public TrajectoryPoint(long timestamp, double[] position, double velocity) {
            this.timestamp = timestamp;
            this.position = position;
            this.velocity = velocity;
        }

        public TrajectoryPoint(long timestamp, double[] position, double[] geo, double velocity) {
            this.timestamp = timestamp;
            this.position = position;
            this.geo = geo;
            this.velocity = velocity;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public double[] getPosition() {
            return position;
        }

        public void setPosition(double[] position) {
            this.position = position;
        }

        public double[] getGeo() {
            return geo;
        }

        public void setGeo(double[] geo) {
            this.geo = geo;
        }

        public double getVelocity() {
            return velocity;
        }

        public void setVelocity(double velocity) {
            this.velocity = velocity;
        }
    }

    public TrajectoryVisualizationDTO() {
    }

    public TrajectoryVisualizationDTO(List<TrajectoryPoint> points, Map<String, Object> metadata) {
        this.points = points;
        this.metadata = metadata;
    }

    public List<TrajectoryPoint> getPoints() {
        return points;
    }

    public void setPoints(List<TrajectoryPoint> points) {
        this.points = points;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
}

