// src/main/java/com/telemetry/kafka/TelemetryKafkaProducer.java
package com.telemetry.kafka;

import com.telemetry.config.KafkaConfig;
import com.telemetry.model.SatelliteReference;
import com.telemetry.dto.TelemetryDto;
import com.telemetry.repository.SatelliteReferenceRepository;
import com.telemetry.service.SatelliteTelemetryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TelemetryKafkaProducer {

    private static final Logger log = LoggerFactory.getLogger(TelemetryKafkaProducer.class);

    @Autowired private KafkaTemplate<String, Object> kafkaTemplate;
    @Autowired private SatelliteTelemetryService     satelliteTelemetryService;
    @Autowired private SatelliteReferenceRepository  referenceRepo;

    /** Every 5 seconds: publish telemetry for each enterprise */
    @Scheduled(fixedRate = 5000)
    public void publishTelemetryForAllEnterprises() {
        List<UUID> enterpriseIds = referenceRepo.findAll().stream()
                .map(SatelliteReference::getEnterpriseId)
                .distinct()
                .collect(Collectors.toList());

        log.debug("Publishing telemetry for {} enterprises", enterpriseIds.size());
        enterpriseIds.forEach(this::publishTelemetryForEnterprise);
    }

    /**
     * Publish telemetry data for a specific enterprise.
     */
    public void publishTelemetryForEnterprise(UUID enterpriseId) {
        try {
            // ← Here we match the service signature exactly:
            Map<Long, TelemetryDto> telemetry =
                    satelliteTelemetryService.getLatestForEnterprise(enterpriseId);

            if (telemetry.isEmpty()) {
                log.debug("No telemetry data for enterprise {}", enterpriseId);
                return;
            }

            Map<String, Object> message = new HashMap<>();
            message.put("enterpriseId", enterpriseId.toString());
            message.put("telemetry",    telemetry);

            kafkaTemplate.send(
                    KafkaConfig.TOPIC_TELEMETRY,
                    enterpriseId.toString(),
                    message
            ).whenComplete((meta, ex) -> {
                if (ex != null) {
                    log.error("Failed to send telemetry for enterprise {}: {}",
                            enterpriseId, ex.getMessage(), ex);
                } else {
                    log.debug("Published telemetry for enterprise {} to partition {}",
                            enterpriseId, meta.getRecordMetadata().partition());
                }
            });

        } catch (Exception e) {
            log.error("Error publishing telemetry for enterprise {}: {}", enterpriseId, e.getMessage(), e);
        }
    }
}
