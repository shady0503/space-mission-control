package com.telemetry.service;

import com.telemetry.dto.TelemetryDto;
import com.telemetry.dto.TelemetryResponse;
import com.telemetry.model.TrajectoryData;
import com.telemetry.model.SatelliteReference;
import com.telemetry.repository.SatelliteReferenceRepository;
import com.telemetry.repository.TrajectoryDataRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
public class SatelliteTelemetryService {

    private final SatelliteReferenceRepository referenceRepo;
    private final TrajectoryDataRepository     trajectoryRepo;
    private final TelemetryService             telemetryService;
    private final RestTemplate                 restTemplate = new RestTemplate();
    private final ExecutorService              executor     = Executors.newFixedThreadPool(10);

    @Value("${n2yo.api.base-url}")
    private String apiBaseUrl;

    @Value("${n2yo.api.key}")
    private String apiKey;

    public SatelliteTelemetryService(
            SatelliteReferenceRepository referenceRepo,
            TrajectoryDataRepository      trajectoryRepo,
            TelemetryService              telemetryService
    ) {
        this.referenceRepo    = referenceRepo;
        this.trajectoryRepo   = trajectoryRepo;
        this.telemetryService = telemetryService;
    }

    /**
     * Poll every ${telemetry.poll.rate:60000}ms:
     * for each SatelliteReference.externalId → fetch & persist.
     */
    @Scheduled(fixedRateString = "${telemetry.poll.rate:60000}")
    public void fetchAllSatelliteTelemetry() {
        List<CompletableFuture<Void>> jobs = referenceRepo.findAll()
                .stream()
                .map(ref -> CompletableFuture.runAsync(() -> {
                    try {
                        TelemetryResponse resp = fetchTelemetry(ref.getExternalId());
                        saveTrajectory(ref.getExternalId(), resp);
                    } catch (Exception e) {
                        // TODO: replace with your logger
                        System.err.println("Telemetry error for " + ref.getExternalId() + ": " + e);
                    }
                }, executor))
                .collect(Collectors.toList());

        CompletableFuture.allOf(jobs.toArray(new CompletableFuture[0])).join();
    }

    private TelemetryResponse fetchTelemetry(long externalId) throws Exception {
        String url  = String.format("%s/%d?apiKey=%s", apiBaseUrl, externalId, apiKey);
        String json = restTemplate.getForObject(url, String.class);
        return telemetryService.parseTelemetryResponse(json);
    }

    /**
     * Save the batch of TrajectoryData built by your TelemetryService helper.
     */
    private void saveTrajectory(long externalId, TelemetryResponse resp) {
        List<TrajectoryData> batch = telemetryService.toTrajectoryEntities(externalId, resp);
        trajectoryRepo.saveAll(batch);
    }

    /**
     * Get the very latest point for every reference in your DB.
     */
    public List<TelemetryDto> getLatestForAll() {
        return referenceRepo.findAll()
                .stream()
                .map(ref ->
                        trajectoryRepo
                                .findFirstByIdExternalIdOrderByIdTimestampDesc(ref.getExternalId())
                                .map(telemetryService::toDto)
                                .orElse(null)
                )
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public Map<Long, TelemetryDto> getLatestForEnterprise(UUID enterpriseId) {

        return referenceRepo.findByEnterpriseId(enterpriseId).stream()
                .collect(Collectors.toMap(
                        SatelliteReference::getExternalId,
                        ref -> trajectoryRepo
                                .findFirstByIdExternalIdOrderByIdTimestampDesc(ref.getExternalId())
                                .map(telemetryService::toDto)
                                .orElse(null)
                ))
                .entrySet().stream()
                .filter(e -> e.getValue() != null)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }


}
