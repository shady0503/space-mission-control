// src/main/java/com/telemetry/service/TelemetryService.java
package com.telemetry.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telemetry.dto.*;
import com.telemetry.model.TrajectoryData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class TelemetryService {

    private static final Logger log = LoggerFactory.getLogger(TelemetryService.class);
    private static final double EARTH_RADIUS_M = 6_378_137.0;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final PredictionService predictionService;

    /** Now keyed by externalId (long) instead of UUID */
    private final Map<Long, double[]> previousVelocityECEF = new HashMap<>();

    public TelemetryService(PredictionService predictionService) {
        this.predictionService = predictionService;
    }

    public TelemetryResponse parseTelemetryResponse(String response) throws Exception {
        JsonNode root = objectMapper.readTree(response);
        if (root.has("error")) {
            throw new Exception("API Error: " + root.get("error").asText());
        }

        TelemetryInfo info = objectMapper.treeToValue(root.get("info"), TelemetryInfo.class);

        JsonNode positionsNode = root.get("positions");
        if (positionsNode == null || !positionsNode.isArray() || positionsNode.size() < 2) {
            throw new Exception("Not enough positions in response");
        }

        List<TelemetryPosition> positions = new ArrayList<>();
        for (JsonNode n : positionsNode) {
            TelemetryPosition pos = objectMapper.treeToValue(n, TelemetryPosition.class);
            long unixSec = n.get("timestamp").asLong();
            pos.setTimestamp(new Timestamp(unixSec * 1000L));
            positions.add(pos);
        }

        return new TelemetryResponse(positions, info);
    }

    /**
     * Converts one TelemetryResponse into one or more TrajectoryData entities
     * keyed by the numeric externalId.
     */
    public List<TrajectoryData> toTrajectoryEntities(long externalId,
                                                     TelemetryResponse resp) {
        List<TelemetryPosition> pos = resp.getPositions();
        if (pos.size() < 2) {
            log.warn("Skipping telemetry for {}: only {} positions", externalId, pos.size());
            return Collections.emptyList();
        }

        TelemetryPosition p1 = pos.get(0);
        TelemetryPosition p2 = pos.get(1);

        // ECEF for the first point
        double[] e1 = toECEF(p1.getSatlatitude(),
                p1.getSatlongitude(),
                p1.getSataltitude() * 1000.0);

        // Δt
        long dtMs = p2.getTimestamp().getTime() - p1.getTimestamp().getTime();
        if (dtMs <= 0) {
            log.warn("Non-positive Δt for {}", externalId);
            return Collections.emptyList();
        }
        double dt = dtMs / 1_000.0;

        // ECEF for the second point
        double[] e2 = toECEF(p2.getSatlatitude(),
                p2.getSatlongitude(),
                p2.getSataltitude() * 1000.0);

        // Velocity vector
        double vx = (e2[0] - e1[0]) / dt;
        double vy = (e2[1] - e1[1]) / dt;
        double vz = (e2[2] - e1[2]) / dt;
        float vX = (float) vx, vY = (float) vy, vZ = (float) vz;
        float speed = (float) Math.sqrt(vx*vx + vy*vy + vz*vz);

        // Acceleration
        float accel = 0f;
        if (previousVelocityECEF.containsKey(externalId)) {
            double[] prev = previousVelocityECEF.get(externalId);
            double ax = (vx - prev[0]) / dt;
            double ay = (vy - prev[1]) / dt;
            double az = (vz - prev[2]) / dt;
            accel = (float) Math.sqrt(ax*ax + ay*ay + az*az);
        }
        previousVelocityECEF.put(externalId, new double[]{vx, vy, vz});

        // Orbit radius
        float orbitRadius = (float) Math.sqrt(e1[0]*e1[0]
                + e1[1]*e1[1]
                + e1[2]*e1[2]);

        // Build the embedded key
        TrajectoryDataKey key = new TrajectoryDataKey(externalId, p1.getTimestamp());

        // Build one TrajectoryData record
        TrajectoryData traj = new TrajectoryData(
                key,
                (float)e1[0], (float)e1[1], (float)e1[2],
                vX, vY, vZ, speed,
                accel, orbitRadius,
                p1.getSatlatitude(),
                p1.getSatlongitude(),
                p1.getSataltitude(),
                p1.getAzimuth(),
                p1.getElevation(),
                p1.getRightAscension(),
                p1.getDeclination()
        );

        return List.of(traj);
    }

    /** Delegate to PredictionService for short‐term extrapolation */
    public List<PredictiveOrbitPoint> predictOrbit(List<TelemetryPosition> positions,
                                                   int steps, int stepSeconds) {
        return predictionService.predictOrbit(positions, steps, stepSeconds);
    }

    /** Delegate to PredictionService for a full 360° orbit */
    public List<PredictiveOrbitPoint> predictFullOrbit(List<TelemetryPosition> positions,
                                                       int numPoints) {
        return predictionService.predictFullOrbit(positions, numPoints);
    }

    /** Simple lat/lon/alt → ECEF (meters) */
    private double[] toECEF(double latDeg, double lonDeg, double altM) {
        double φ = Math.toRadians(latDeg);
        double λ = Math.toRadians(lonDeg);
        double r = EARTH_RADIUS_M + altM;
        return new double[]{
                r * Math.cos(φ) * Math.cos(λ),
                r * Math.cos(φ) * Math.sin(λ),
                r * Math.sin(φ)
        };
    }

    public TelemetryDto toDto(TrajectoryData d) {
        return new TelemetryDto(
                d.getId().getExternalId(),
                d.getTimestamp(),
                d.getSatLatitude(),
                d.getSatLongitude(),
                d.getSatAltitude(),
                d.getVelocity(),
                d.getAcceleration()
        );
    }
}
