package com.telemetry.websocket;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class TelemetryWebSocketHandler extends TextWebSocketHandler {

    private static final Logger log = LoggerFactory.getLogger(TelemetryWebSocketHandler.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final Map<UUID, CopyOnWriteArrayList<WebSocketSession>> enterpriseSessions = new ConcurrentHashMap<>();
    private final Map<String, UUID> sessionToEnterprise = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        try {
            UUID enterpriseId = extractEnterpriseId(session);
            if (enterpriseId == null) {
                closeWithError(session, "Missing enterpriseId");
                return;
            }

            enterpriseSessions
                    .computeIfAbsent(enterpriseId, k -> new CopyOnWriteArrayList<>())
                    .add(session);
            sessionToEnterprise.put(session.getId(), enterpriseId);

            Map<String,Object> ok = Map.of(
                    "type","CONNECTION_SUCCESS",
                    "enterpriseId", enterpriseId.toString()
            );
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(ok)));

            log.info("WS {} connected to {}", session.getId(), enterpriseId);

        } catch (Exception e) {
            log.error("WS error: {}", e.getMessage());
            closeWithError(session, "Connection error");
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        UUID eid = sessionToEnterprise.remove(session.getId());
        if (eid != null) {
            var list = enterpriseSessions.get(eid);
            if (list != null) {
                list.remove(session);
                if (list.isEmpty()) enterpriseSessions.remove(eid);
            }
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession s, TextMessage m) {
        try {
            JsonNode n = objectMapper.readTree(m.getPayload());
            if ("PING".equals(n.path("type").asText())) {
                s.sendMessage(new TextMessage("{\"type\":\"PONG\"}"));
            }
        } catch (Exception ignore) {}
    }

    public void sendMessageToEnterprise(UUID enterpriseId, TextMessage msg) {
        var sessions = enterpriseSessions.get(enterpriseId);
        if (sessions == null) return;
        sessions.forEach(ws -> {
            try { if (ws.isOpen()) ws.sendMessage(msg); }
            catch (IOException ignored) {}
        });
    }

    // helpers
    private UUID extractEnterpriseId(WebSocketSession s) {
        String q = s.getUri() != null ? s.getUri().getQuery() : null;
        if (q == null) return null;
        for (String p : q.split("&")) {
            String[] kv = p.split("=",2);
            if (kv.length==2 && kv[0].equals("enterpriseId")) {
                return UUID.fromString(URLDecoder.decode(kv[1], StandardCharsets.UTF_8));
            }
        }
        return null;
    }
    private void closeWithError(WebSocketSession s,String msg){ try{
        s.sendMessage(new TextMessage("{\"type\":\"ERROR\",\"message\":\""+msg+"\"}"));
        s.close(CloseStatus.POLICY_VIOLATION);}catch(IOException ignored){} }
}
